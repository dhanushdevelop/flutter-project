import 'package:flutter/material.dart';
import 'package:weather/models/weathermodels.dart';

import '../services/weatherservice.dart';

class weatherpage extends StatefulWidget{
  const weatherpage({super.key});

  @override
  State<weatherpage> createState() => _weatherpageState();
}

class _weatherpageState extends State<weatherpage> {
  final _weatherservice = weatherservice(apikey!);
  weather? _weather;

  static String? get apikey => null;

  _featchweather() async {
    String cityName = await _weatherservice.getCurrentCity();

    try {
      final weather = await _weatherservice.getweather(cityName);
      setState(() {
        _weather = weather;
      });
    }
    catch (e) {
      print(e);
    }
  }

  @override
  void iniState(){
    super.initState();

        _featchweather();
  }

  @override
  Widget build(BuildContext contetx) {
    return Scaffold(
      body: Column(
        children: [
          Text(_weather?.cityName ?? "Loading city.."),
          Text(_weather!.temperature.round().toString()+ '*c')
        ],
      ),
    );
  }
}

